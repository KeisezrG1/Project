import java.util.List;

public interface DataAccess {
    void connect(String str);

    void saveProduct(ProductModel product);

    ProductModel loadProduct(int productID);

//    List<ProductModel> loadAllProducts();
    UserModel loadUser(int userID);
    OrderModel loadOrder(int orderID);

    void saveOrder(OrderModel order);
    OrderModel cancelOrder(int orderID);
    ProductModel updatePrice(int productID);
    ProductModel updateQuantity(int productID);

    UserModel loadUser(String username, String password);
}
