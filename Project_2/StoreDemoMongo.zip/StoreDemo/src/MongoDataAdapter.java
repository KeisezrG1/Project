import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class MongoDataAdapter implements DataAccess {

    private MongoClient mongoClient = null;
    private static String conStr = "mongodb+srv://tungisu:ttudbms1@cluster1.cryxyah.mongodb.net";

    @Override
    public void connect(String str) {
        if (mongoClient != null)
            mongoClient.close();
        mongoClient = new MongoClient(new MongoClientURI(str));
    }

    @Override
    public void saveProduct(ProductModel product) {

    }

    @Override
    public ProductModel loadProduct(int productID) {
        this.connect(conStr);
        ProductModel product = null;
        try {
            // Connect to the database
            MongoDatabase database = mongoClient.getDatabase("store");

            // Access a collection
            MongoCollection<Document> collection = database.getCollection("products");

            MongoCursor<Document> cursor = collection.find(eq("_id", productID) ).iterator();

            if (cursor.hasNext()) {
                product = new ProductModel();
                Document doc = cursor.next();
                product.setProductID(productID);
                product.setName(doc.getString("name"));
                product.setPrice(doc.getDouble("price"));
                product.setQuantity(doc.getDouble("quantity"));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        this.mongoClient.close();

        return product;
   }

/*    @Override
    public List<ProductModel> loadAllProducts() {
        List<ProductModel> list = new ArrayList<>();
        ProductModel product = null;
        try {
            this.connect(conStr);
            MongoDatabase database = mongoClient.getDatabase("store");

            // Access a collection
            MongoCollection<Document> collection = database.getCollection("products");

            MongoCursor<Document> cursor = collection.find().iterator();

            while (cursor.hasNext()) {
                Document doc = cursor.next();
                product = new ProductModel();
                product.productID = doc.getInteger("_id");;
                product.name = doc.getString("name");
                product.price = doc.getDouble("price");
                product.quantity = doc.getDouble("quantity");
                list.add(product);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

 */

    @Override
    public UserModel loadUser(int userID) {
        return null;
    }

    @Override
    public OrderModel loadOrder(int orderID) {
        return null;
    }

    @Override
    public void saveOrder(OrderModel order) {

    }

    @Override
    public OrderModel cancelOrder(int orderID) {
        return null;
    }

    @Override
    public ProductModel updatePrice(int productID) {
        return null;
    }

    @Override
    public ProductModel updateQuantity(int productID) {
        return null;
    }

    @Override
    public UserModel loadUser(String username, String password) {
        UserModel user = null;
        try {

            this.connect(conStr);
            // Connect to the database
            MongoDatabase database = mongoClient.getDatabase("store");

            // Access a collection
            MongoCollection<Document> collection = database.getCollection("users");

            MongoCursor<Document> cursor = collection.find(eq("UserName", username) ).iterator();

            if (cursor.hasNext()) {
                Document doc = cursor.next();

                if (doc.getString("Password").equals(password)) {

                    user = new UserModel();
                    user.setUserID(doc.getInteger("_id"));
                    user.setUsername(doc.getString("UserName"));
                    user.setPassword(doc.getString("Password"));
                    user.setFullName(doc.getString("FullName"));
                }
            }

        } catch (Exception e) {
            System.out.println("Database access error!");
            e.printStackTrace();
        }
        return user;
    }
}
